#include "PriorityQueue.h"
#include <iostream>
using namespace std;

PriorityQueue::PriorityQueue(int capacity) : arr(new int[capacity]), capacity(capacity), elemNum(0), f(-1), r(0) {}
												
	
PriorityQueue::~PriorityQueue()
{
	delete [] this->arr;
	this->arr = nullptr;
	this->elemNum = 0;
	this->capacity = 0;
}

int PriorityQueue::isEmpty(PriorityQueue* queue)
{
	return queue->f ==-1 || queue->f == queue->r;
}

int PriorityQueue::isFull(PriorityQueue* queue)
{
	return queue->r == queue->capacity;
}


void PriorityQueue::enqueue(PriorityQueue *queue, int value)
{
	if (isFull(queue))
	{
		int* newArr = new int[this->capacity*2];
		this->capacity *=2;                            // queue-> umjesto this za presjek!
		for (int i = 0; i < this->elemNum; i++)
		{
			newArr[i] = this->arr[i];
		}
		delete [] this->arr;
		this->arr = newArr;
	}

	if (queue->f == -1)  
	{
		queue->f++;
		queue->arr[queue->r++] = value;
		queue->elemNum++;
	}
	else
	{
		int i = queue->elemNum-1;
		while (value > queue->arr[i] && i >= 0)
		{
			queue->arr[i + 1] = queue->arr[i];
			i--;
		}
		queue->arr[i + 1] = value;
		queue->r++;
		queue->elemNum++;
	}

	/*if (queue->f == -1)
		queue->f = 0;
	queue->arr[queue->r++] = value;
	queue->elemNum++;
	sort(queue);*/
}

bool PriorityQueue::dequeue(PriorityQueue *queue)
{
	if (isEmpty(queue))
		return false;
	
	for (int i = this->f+1; i < this->r; i++)
	{
		this->arr[i - 1] = this->arr[i];
	}
	this->r--;
	this->elemNum--;
	return true;
}

bool PriorityQueue::removeAt(int idx)
{
	if (idx < 0 || idx >= this->elemNum)
		return false;

	for (int i = idx; i < this->elemNum-1; i++)
	{
		this->arr[i] = this->arr[i + 1];	
	}
	this->elemNum--;
	this->r--;

	if (this->shouldShrink())
	{
		int* newArr2 = new int[this->elemNum]();
		this->capacity = this->elemNum;
		this->elemNum = this->capacity > this->elemNum ? this->elemNum : this->capacity;
		for (int i = 0; i < this->elemNum; i++)
		{
			newArr2[i] = this->arr[i];
		}
		delete [] this->arr;
		this->arr = newArr2;	
	}
	return true;
}

int PriorityQueue::search(int value)
{
	for (int i = 0; i < this->elemNum; i++)
	{
		if (this->arr[i] == value)
		{
			return i;
		}
	}
	return -1;
}

/*bool PriorityQueue::removeByValue(int value)
{
	return removeAt(search(value));
}*/

bool PriorityQueue::shouldShrink()
{
	return this->elemNum <= this->capacity / 2;
}

void PriorityQueue::print(PriorityQueue *queue)
{
	if (this->f != -1)
		for (int i = this->f; i < this->r; i++) 
		{
			cout << this->arr[i] << " ";
		}
}

/*void PriorityQueue::presjek(const PriorityQueue& other, PriorityQueue& other2)
{
	for(int i=0; i<this->r; i++)
	{
		for (int j = 0; j < other.r; j++) 
		{
			if (this->arr[i] == other.arr[j])
			{
				enqueue(&other2, this->arr[i]);
			}
		}	
	}
}*/

/*void PriorityQueue::sabiranje(const PriorityQueue& other, PriorityQueue& other3)
{
	int i=0;
	while (i<this->r)
	{
		for (int j = 0; j < other.r; j++)
		{
				enqueue(&other3, this->arr[i]+other.arr[j]);
				i++;
		}
	}
}*/

/* void PriorityQueue::sort(PriorityQueue* queue)
{
	for (int i = 0; i < red->elemNum-1; i++)
	{
		for (int j = i + 1; j <red->elemNum; j++)
		{
			if (red->arr[i] < red->arr[j])
			{
				int pom = arr[i];
				arr[i] = arr[j];
				arr[j] = pom;
			}
		}
	}

}*/

