#include "PriorityQueue.h"
#include <iostream>

using namespace std;

int main()
{
	PriorityQueue Queue(5);

	// PriorityQueue Q2(20);
	// PriorityQueue Q3(10);

		cout << "\nPrikaz originalnog niza: ";

	Queue.enqueue(&Queue, 1);
	Queue.enqueue(&Queue, 15);
	Queue.enqueue(&Queue, 2);
	Queue.enqueue(&Queue, 12);
	Queue.enqueue(&Queue, 4);
	Queue.enqueue(&Queue, 78);
	Queue.enqueue(&Queue, 23);

		Queue.print(&Queue);
		cout << "\n\n";

	/*Q2.enqueue(&Q2, 3);
	Q2.enqueue(&Q2, 6);
	Q2.enqueue(&Q2, 567);
	Q2.enqueue(&Q2, 2);
	Q2.enqueue(&Q2, 568);
	Q2.enqueue(&Q2, 77);
	Q2.enqueue(&Q2, 9);

		Q2.print(&Q2);
		cout << "\n\n"; */


	/*Queue.sabiranje(Q2, Q3);
		Q3.print(&Q3);
		cout << "\n\n";*/

	/*Queue.presjek(Q2, Q3);
		Q3.print(&Q3);
		cout << "\n\n";*/

	/*Q3.dequeue(&Q3);
		Q3.print(&Q3);
		cout << "\n\n";*/

	Queue.dequeue(&Queue);
	
		cout <<"\nPrikaz reda nakon brisanja po prioritetu: ";
		Queue.print(&Queue);
	
	Queue.removeAt(3);
		cout << "\nNakon brisanja na poziciji 3: ";
		Queue.print(&Queue);

	Queue.dequeue(&Queue);
	
		cout << "\nPrikaz reda nakon brisanja po prioritetu: ";
		Queue.print(&Queue);
	
	Queue.removeAt(2);
		cout << "\nNakon brisanja na poziciji 2: ";
		Queue.print(&Queue);
		cout << "\n";

	// Queue.enqueue(&Queue, 56);
		cout << "\nNovi niz: ";
		Queue.print(&Queue);

	cout << "\n";
	cout << "\n";

}