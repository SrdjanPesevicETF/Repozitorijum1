#pragma once
class PriorityQueue
{
private:
	int* arr;
	int capacity; // kapacitet niza
	int elemNum; // broj elemenata niza, reda
	int f, r; // front, rear

public:
	PriorityQueue(int capacity = 1);
	~PriorityQueue();
	int isEmpty(PriorityQueue* queue);   // Prazan red?
	int isFull(PriorityQueue* queue);    // Pun red?
	void enqueue(PriorityQueue *queue, int value);    // dodaj u red
	bool dequeue(PriorityQueue *queue);     // izbaci iz reda
	bool removeAt(int idx);   // izbaci el sa indeksa
	int search(int value);    // pronadji indeks elementa
	bool shouldShrink();       // pomocna za realokaciju
	void print(PriorityQueue *queue);     // ispis reda
	// void presjek(const PriorityQueue&, PriorityQueue&);
	// void sabiranje(const PriorityQueue&, PriorityQueue&);
	// void sort(PriorityQueue *queue);	
	// bool removeByValue(int value);  // izbaci po vrijednosti
};